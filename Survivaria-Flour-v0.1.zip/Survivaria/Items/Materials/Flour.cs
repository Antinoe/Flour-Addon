﻿using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Survivaria.Items.Materials;
using Survivaria.Tiles.Stations;


namespace Survivaria.Items.Materials
{
    public class Flour : SurvivariaItem
    {
        public Flour() : base("Flour", "A finely ground up grain.", 20, 30, Item.buyPrice(0, 0, 1, 0), ItemRarityID.Blue, 0, 0)
        {
        }
		
		/*public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Flour");
			Tooltip.SetDefault("A finely ground up grain.");
		}
		
		public override void SetDefaults() 
		{
			item.width = 1;
			item.height = 1;
			item.maxStack = 999;
			item.value = 100;
			item.rare = 1;
		}*/
		
		public override void AddRecipes()
        {
            ModRecipe recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<BlossomWheat>());
			recipe.AddTile(ModContent.TileType<GrindStoneTile>());
            recipe.SetResult(this);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(mod);
            recipe.AddIngredient(ModContent.ItemType<Reece>());
			recipe.AddTile(ModContent.TileType<GrindStoneTile>());
            recipe.SetResult(this);
            recipe.AddRecipe();
			
			recipe = new ModRecipe(mod);
            recipe.AddIngredient(ItemID.Hay, 40);
            recipe.AddTile(ModContent.TileType<GrindStoneTile>());
            recipe.SetResult(this);
            recipe.AddRecipe();

        }
    }
}
